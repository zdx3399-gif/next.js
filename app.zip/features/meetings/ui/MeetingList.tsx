"use client"

import { useState } from "react"
import { useMeetings } from "../hooks/useMeetings"
import { MeetingDetails } from "./MeetingDetails"

export function MeetingList() {
  const { meetings, loading, error } = useMeetings()
  const [selectedMeetingId, setSelectedMeetingId] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredMeetings = meetings.filter((meeting) => {
    if (!searchTerm) return true
    const term = searchTerm.toLowerCase()
    return (
      meeting.topic.toLowerCase().includes(term) ||
      meeting.location?.toLowerCase().includes(term) ||
      false ||
      new Date(meeting.time).toLocaleDateString("zh-TW").includes(term)
    )
  })

  if (selectedMeetingId) {
    return <MeetingDetails meetingId={selectedMeetingId} onBack={() => setSelectedMeetingId(null)} />
  }

  // ... existing loading and error states ...

  return (
    <div className="bg-[var(--theme-bg-card)] border border-[var(--theme-border)] rounded-2xl p-5">
      <h2 className="flex gap-2 items-center text-[var(--theme-accent)] mb-5 text-xl">
        <span className="material-icons">event</span>
        會議/活動
      </h2>

      <div className="mb-4">
        <input
          type="text"
          placeholder="搜尋會議主題、地點或日期..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 rounded-xl theme-input outline-none"
        />
      </div>

      <div className="space-y-3">
        {filteredMeetings.length > 0 ? (
          filteredMeetings.map((meeting) => (
            <div key={meeting.id} className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-lg font-bold">{meeting.topic}</h3>
              <p className="text-gray-600">地點: {meeting.location}</p>
              <p className="text-gray-600">日期: {new Date(meeting.time).toLocaleDateString("zh-TW")}</p>
            </div>
          ))
        ) : (
          <div className="text-center text-[var(--theme-text-muted)] py-8">
            {searchTerm ? "沒有符合條件的會議/活動" : "目前沒有會議/活動"}
          </div>
        )}
      </div>
    </div>
  )
}
